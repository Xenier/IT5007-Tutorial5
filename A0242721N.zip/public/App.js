"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var DisplayHomepage = /*#__PURE__*/function (_React$Component) {
  _inherits(DisplayHomepage, _React$Component);

  var _super = _createSuper(DisplayHomepage);

  function DisplayHomepage() {
    _classCallCheck(this, DisplayHomepage);

    return _super.apply(this, arguments);
  }

  _createClass(DisplayHomepage, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement("div", {
        id: "DisplayHomepage"
      }, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("h1", null, "Hotel Waitlist System"), /*#__PURE__*/React.createElement("div", {
        className: "navbar"
      }, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("nav", null, /*#__PURE__*/React.createElement("a", null, " Hotel California "), " |", /*#__PURE__*/React.createElement("a", {
        href: "#DisplayHomepage"
      }, " Homepage "), " |", /*#__PURE__*/React.createElement("a", {
        href: "#Menu"
      }, " Menu "), " |"), /*#__PURE__*/React.createElement("br", null)));
    }
  }]);

  return DisplayHomepage;
}(React.Component);

function DisplayFreeSlots(props) {
  if (props.free > 1) {
    return /*#__PURE__*/React.createElement("div", {
      id: "DisplayFreeSlots"
    }, /*#__PURE__*/React.createElement("p", null, "Now there are ", props.free, " slots available."));
  } else if (props.free == 1) {
    return /*#__PURE__*/React.createElement("div", {
      id: "DisplayFreeSlots"
    }, /*#__PURE__*/React.createElement("p", null, "Now there is only 1 slot available."));
  } else {
    return /*#__PURE__*/React.createElement("div", {
      id: "DisplayFreeSlots"
    }, /*#__PURE__*/React.createElement("p", null, "Sorry. There is no slot available now."));
  }
}

var Menu = /*#__PURE__*/function (_React$Component2) {
  _inherits(Menu, _React$Component2);

  var _super2 = _createSuper(Menu);

  function Menu() {
    _classCallCheck(this, Menu);

    return _super2.apply(this, arguments);
  }

  _createClass(Menu, [{
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement("div", {
        id: "Menu"
      }, /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("h2", null, "Menu"), /*#__PURE__*/React.createElement("a", {
        href: "#AddCustomer"
      }, "Add"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("a", {
        href: "#DeleteCustomer"
      }, "Remove"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("a", {
        href: "#DisplayCustomers"
      }, "Display"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null));
    }
  }]);

  return Menu;
}(React.Component);

function CustomerRow(props) {
  var customer = props.customer;
  return /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", null, customer.serialNo), /*#__PURE__*/React.createElement("td", null, customer.name), /*#__PURE__*/React.createElement("td", null, customer.phone), /*#__PURE__*/React.createElement("td", null, customer.timeStamp.toDateString()));
}

function EmptyRow() {
  return /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", null, "\xA0"), /*#__PURE__*/React.createElement("td", null, "\xA0"), /*#__PURE__*/React.createElement("td", null, "\xA0"), /*#__PURE__*/React.createElement("td", null, "\xA0"));
}

var AddCustomer = /*#__PURE__*/function (_React$Component3) {
  _inherits(AddCustomer, _React$Component3);

  var _super3 = _createSuper(AddCustomer);

  function AddCustomer() {
    var _this;

    _classCallCheck(this, AddCustomer);

    _this = _super3.call(this);
    _this.handleSubmit = _this.handleSubmit.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(AddCustomer, [{
    key: "handleSubmit",
    value: function handleSubmit(e) {
      e.preventDefault();
      var form = document.forms.customerAdd;
      var customer = {
        name: form.name.value,
        phone: form.phone.value
      };

      if (this.props.free > 0) {
        this.props.newCustomer(customer);
      }

      form.name.value = "";
      form.phone.value = "";
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement("div", {
        id: "AddCustomer"
      }, /*#__PURE__*/React.createElement("h4", null, "Add"), /*#__PURE__*/React.createElement("form", {
        name: "customerAdd",
        onSubmit: this.handleSubmit
      }, /*#__PURE__*/React.createElement("fieldset", null, /*#__PURE__*/React.createElement("legend", null, "Add a new customer"), /*#__PURE__*/React.createElement("input", {
        type: "text",
        name: "name",
        placeholder: "name"
      }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("input", {
        type: "text",
        name: "phone",
        placeholder: "phone number"
      }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("button", null, "Add"), /*#__PURE__*/React.createElement("br", null))));
    }
  }]);

  return AddCustomer;
}(React.Component);

var DeleteCustomer = /*#__PURE__*/function (_React$Component4) {
  _inherits(DeleteCustomer, _React$Component4);

  var _super4 = _createSuper(DeleteCustomer);

  function DeleteCustomer() {
    var _this2;

    _classCallCheck(this, DeleteCustomer);

    _this2 = _super4.call(this);
    _this2.handleSubmit = _this2.handleSubmit.bind(_assertThisInitialized(_this2));
    return _this2;
  }

  _createClass(DeleteCustomer, [{
    key: "handleSubmit",
    value: function handleSubmit(e) {
      e.preventDefault();
      var form = document.forms.customerRemove;
      var r = Number(form.removeNo.value);
      this.props.removeCustomer(r);
      form.removeNo.value = "";
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement("div", {
        id: "DeleteCustomer"
      }, /*#__PURE__*/React.createElement("h4", null, "Remove"), /*#__PURE__*/React.createElement("form", {
        name: "customerRemove",
        onSubmit: this.handleSubmit
      }, /*#__PURE__*/React.createElement("fieldset", null, /*#__PURE__*/React.createElement("legend", null, "Remove an existing customer"), /*#__PURE__*/React.createElement("input", {
        type: "text",
        name: "removeNo",
        placeholder: "Serial No."
      }), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("button", null, "Remove"), /*#__PURE__*/React.createElement("br", null))));
    }
  }]);

  return DeleteCustomer;
}(React.Component);

function DisplayCustomers(props) {
  var customerRows = props.customers.map(function (customer) {
    return /*#__PURE__*/React.createElement(CustomerRow, {
      key: customer.serialNo,
      customer: customer
    });
  });
  return /*#__PURE__*/React.createElement("div", {
    id: "DisplayCustomers"
  }, /*#__PURE__*/React.createElement("h4", null, "Display"), /*#__PURE__*/React.createElement("form", null, /*#__PURE__*/React.createElement("fieldset", null, /*#__PURE__*/React.createElement("legend", null, "Current waitlist"), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("table", null, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    id: "tr1"
  }, /*#__PURE__*/React.createElement("td", null, "Serial No."), /*#__PURE__*/React.createElement("td", null, "Name"), /*#__PURE__*/React.createElement("td", null, "Phone number"), /*#__PURE__*/React.createElement("td", null, "Time Stamp"))), /*#__PURE__*/React.createElement("tbody", null, customerRows, FreeRows)), /*#__PURE__*/React.createElement("br", null))));
}

var Waitlist = /*#__PURE__*/function (_React$Component5) {
  _inherits(Waitlist, _React$Component5);

  var _super5 = _createSuper(Waitlist);

  function Waitlist() {
    var _this3;

    _classCallCheck(this, Waitlist);

    _this3 = _super5.call(this);
    _this3.state = {
      customers: []
    };
    _this3.newCustomer = _this3.newCustomer.bind(_assertThisInitialized(_this3));
    _this3.removeCustomer = _this3.removeCustomer.bind(_assertThisInitialized(_this3));
    return _this3;
  }

  _createClass(Waitlist, [{
    key: "newCustomer",
    value: function newCustomer(customer) {
      customer.serialNo = this.state.customers.length + 1;
      customer.timeStamp = new Date();
      var newWaitlist = this.state.customers.slice();
      newWaitlist.push(customer);
      this.setState({
        customers: newWaitlist
      });
    }
  }, {
    key: "removeCustomer",
    value: function removeCustomer(r) {
      var newWaitlist = this.state.customers.slice();

      if (r > 0 && r <= newWaitlist.length) {
        newWaitlist.splice(r - 1, 1);
      }

      var tmpWaitlist = newWaitlist.slice();

      for (var i = 0; i < tmpWaitlist.length; i++) {
        tmpWaitlist[i].serialNo = i + 1;
      }

      this.setState({
        customers: tmpWaitlist
      });
    }
  }, {
    key: "render",
    value: function render() {
      return /*#__PURE__*/React.createElement("div", {
        className: "Waitlist"
      }, /*#__PURE__*/React.createElement(DisplayHomepage, null), /*#__PURE__*/React.createElement(DisplayFreeSlots, {
        free: 20 - this.state.customers.length
      }), /*#__PURE__*/React.createElement(Menu, null), /*#__PURE__*/React.createElement(AddCustomer, {
        newCustomer: this.newCustomer,
        free: 20 - this.state.customers.length
      }), /*#__PURE__*/React.createElement(DeleteCustomer, {
        removeCustomer: this.removeCustomer
      }), /*#__PURE__*/React.createElement(DisplayCustomers, {
        customers: this.state.customers
      }));
    }
  }]);

  return Waitlist;
}(React.Component);

ReactDOM.render( /*#__PURE__*/React.createElement(Waitlist, null), document.getElementById('Content'));